const express = require('express')
const cors = require('cors');
const axios = require('axios')

const serverless = require("serverless-http");

const app = express()
const port = 3001

app.use(cors());
app.use(express.json());
app.use(
  express.urlencoded({
    extended: true
  })
)



// Add headers before the routes are defined
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});
var token = '';
const login = () => (req, res, next) => {
  axios({
    method: "post",
    url: "http://payload.eba-c42n922u.us-east-2.elasticbeanstalk.com/api/users/login",
    data: {
      "email": "bilal@starmarketingonline.com",
      "password": "Admin123"
    },
    headers: {
      'Content-Type': 'application/json',
    }
  })
    .then(response => {
      console.log(response)
      token = response.data.token
      next()
    })
    .catch(error => {
      console.error(error)
    })
}

app.get('/home', login(), (req, res) => {
  axios({
    method: "get",
    url: "http://payload.eba-c42n922u.us-east-2.elasticbeanstalk.com/api/bumblebee/61fd2d77bfcc9c1423dac8f9",
    // data: req.body,
    headers: {
    'Content-Type': 'application/json',
    'Cookie':'payload-token='+token,
    }
  })
  .then(response => {
    // console.log(response)
    res.status(response.status).send(response.data)
  })
  .catch(error => {
    // console.error(error)
    res.status(error.response.status).send(error.response.data)
  })
})


app.get('/about', login(), (req, res) => {
  axios({
    method: "get",
    url: "http://payload.eba-c42n922u.us-east-2.elasticbeanstalk.com/api/bumblebee/61fd2fc8bfcc9c1423dac9b3",
    // data: req.body,
    headers: {
    'Content-Type': 'application/json',
    'Cookie':'payload-token='+token,
    }
  })
  .then(response => {
    // console.log(response)
    res.status(response.status).send(response.data)
  })
  .catch(error => {
    // console.error(error)
    res.status(error.response.status).send(error.response.data)
  })
})

// app.listen(port, () => {
//   console.log(`Example app listening on port ${port}`)
// })

module.exports.handler = serverless(app);